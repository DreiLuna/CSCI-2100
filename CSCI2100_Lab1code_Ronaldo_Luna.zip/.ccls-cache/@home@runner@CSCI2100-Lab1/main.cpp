#include <iostream>
#include <cctype>
using namespace std;

int main() {
    float temperature;
    char unit;
    float temp;
    bool valid = false;
    while(valid == false){
    string converted_unit;
        // TODO: Prompt user to enter temperature
        cout << "Enter the temperature: ";
        cin >> temperature;
        
        // TODO: Prompt user to enter unit (F for Fahrenheit, C for Celsius)
        cout << "Enter the unit: ";
        cin >> unit;
        
        // TODO: Convert temperature to the other unit
        if(unit == 'F' || unit == 'f') {
            // Convert Fahrenheit to Celsius
            // TODO: Implement the conversion formula here
            temp = (temperature - 32) * 5 / 9;
            converted_unit = 'C';
            valid = true;
            char upper_unit = std::toupper(unit);
            cout << "you have converted " << temperature << upper_unit << " to " << temp << converted_unit << endl;
        } else if(unit =='C' || unit =='c' ) {
            // Convert Celsius to Fahrenheit
            // TODO: Implement the conversion formula here
            temp = (temperature*9/5) + 32;
            valid = true;
            converted_unit = 'F';
            char upper_unit = std::toupper(unit);
            cout << "you have converted " << temperature << upper_unit << " to " << temp << converted_unit << endl;
        } else {
            // Handle invalid input
            // TODO: Display an error message
            cout << "Invalid unit. Please enter F or C." << endl;
            valid = false;
        }

    }
    return 0;
}

